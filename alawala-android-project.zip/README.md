# Alawala Aluminium Android App

This project packages the existing online app in an Android WebView:
https://alawala-aluminium.gayan86000.workers.dev/

## Build the APK
1. Create a new GitHub repository.
2. Upload the CONTENTS of this ZIP to the repository's main branch.
3. Open the Actions tab and run **Build Alawala Aluminium APK**.
4. When it finishes, download the **Alawala-Aluminium-Android-APK** artifact.
5. Extract it to get `app-debug.apk`, transfer it to your Android phone, and install it. Allow installs from that source if Android asks.

## Important
- This is an online wrapper, not a full offline-native rewrite; internet is needed.
- Storage inside this app is separate from Chrome storage. Documents saved in Chrome will not automatically appear here. Export a JSON backup from the existing app first and restore it in the new app if needed.
- This project has not been built or tested on a physical Android phone here.
- The generated APK is debug-signed for testing/personal use, not a Play Store release.
