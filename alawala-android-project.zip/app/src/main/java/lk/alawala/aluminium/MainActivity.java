package lk.alawala.aluminium;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class MainActivity extends Activity {
 private WebView webView;
 private static final String APP_URL="https://alawala-aluminium.gayan86000.workers.dev/";
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  webView=new WebView(this); setContentView(webView);
  WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
  s.setLoadWithOverviewMode(true); s.setUseWideViewPort(true); s.setJavaScriptCanOpenWindowsAutomatically(true);
  webView.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){
    Uri u=r.getUrl(); String h=u.getHost()==null?"":u.getHost();
    if(("https".equals(u.getScheme())||"http".equals(u.getScheme())) && h.equals("alawala-aluminium.gayan86000.workers.dev")) return false;
    try { startActivity(new Intent(Intent.ACTION_VIEW,u)); } catch(Exception e){ Toast.makeText(MainActivity.this,"Unable to open link",Toast.LENGTH_SHORT).show(); }
    return true;
   }
  });
  webView.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p){ cb.onReceiveValue(null); return true; }
  });
  webView.loadUrl(APP_URL);
 }
 @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
